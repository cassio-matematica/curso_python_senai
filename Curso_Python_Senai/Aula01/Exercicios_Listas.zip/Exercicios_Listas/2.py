##Exercício 2: Maior elemento
###Escreva um programa que recebe uma lista de números do usuário e retorna o maior elemento presente na lista.

numeros = input("Digite uma lista de números separados por espaço: ").split()
numeros = [int(num) for num in numeros]
maior = max(numeros)
print("O maior número é:", maior)
