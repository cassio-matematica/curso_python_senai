##Exercício 3: Concatenação de tuplas
##Escreva um programa que declare duas tuplas e crie uma terceira tupla que contenha os elementos das duas tuplas originais.

tupla1 = (1, 2, 3)
tupla2 = (4, 5, 6)
tupla3 = tupla1 + tupla2
print("Tupla 1:", tupla1)
print("Tupla 2:", tupla2)
print("Tupla concatenada:", tupla3)
