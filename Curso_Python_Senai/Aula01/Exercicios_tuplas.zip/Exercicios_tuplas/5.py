##Exercício 5: Desempacotamento de tupla
##Escreva um programa que declare uma tupla com alguns elementos e atribua cada elemento a uma variável separada.

tupla = (10, 20, 30, 40, 50)
a, b, c, d, e = tupla
print("a =", a)
print("b =", b)
print("c =", c)
print("d =", d)
print("e =", e)
