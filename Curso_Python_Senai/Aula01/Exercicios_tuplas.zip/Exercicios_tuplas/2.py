##Exercício 2: Contagem de elementos
##Escreva um programa que declare uma tupla com alguns elementos e exiba a quantidade de vezes que um elemento específico aparece na tupla.

tupla = (1, 2, 3, 2, 4, 2, 5, 2)
elemento = 2
contagem = tupla.count(elemento)
print("O elemento", elemento, "aparece", contagem, "vezes na tupla.")
