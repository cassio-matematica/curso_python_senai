##Exercício 1: Acesso aos elementos
##Escreva um programa que declare uma tupla com alguns elementos e exiba o valor do primeiro e último elemento.

tupla = (10, 20, 30, 40, 50)
primeiro_elemento = tupla[0]
ultimo_elemento = tupla[-1]
print("Primeiro elemento:", primeiro_elemento)
print("Último elemento:", ultimo_elemento)
